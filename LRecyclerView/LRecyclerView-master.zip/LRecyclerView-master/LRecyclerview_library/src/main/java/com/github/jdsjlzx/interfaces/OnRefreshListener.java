package com.github.jdsjlzx.interfaces;

/**
 * 下拉刷新事件
 * @author jdsjlzx
 * @created 2016/9/30 14:17
 *
 */

public interface OnRefreshListener {
    void onRefresh();
}
