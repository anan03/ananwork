package com.github.jdsjlzx.interfaces;

/**
 * 加载更多事件
 * @author jdsjlzx
 * @created 2016/9/30 14:09
 *
 */
public interface OnLoadMoreListener {

    void onLoadMore();

}
