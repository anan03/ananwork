package com.github.jdsjlzx.interfaces;

import android.view.View;

/**
 * LongClick
 */

public interface OnItemLongClickListener {
    void onItemLongClick(View view , int position);
}
