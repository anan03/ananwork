package com.github.jdsjlzx.interfaces;

import android.view.View;

/**
 * Click
 */
public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
