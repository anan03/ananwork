package com.github.jdsjlzx.interfaces;

/**
 * 网络错误点击事件
 * @author jdsjlzx
 * @created 20167/1/02 14:17
 *
 */

public interface OnNetWorkErrorListener {
    void reload();
}
