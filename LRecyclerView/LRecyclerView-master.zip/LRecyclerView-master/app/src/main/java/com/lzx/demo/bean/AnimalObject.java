package com.lzx.demo.bean;

/**
 * Created by faudigue on 30/04/2015.
 */
public class AnimalObject {

    public String name;
    public String type;

    public AnimalObject(final String name, final String type){

        this.name = name ;
        this.type = type ;
    }
}
