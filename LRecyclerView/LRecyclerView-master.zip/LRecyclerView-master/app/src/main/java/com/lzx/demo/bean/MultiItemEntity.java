package com.lzx.demo.bean;

public interface MultiItemEntity {

    int getItemType();

}
