package com.lzx.demo.bean;


import com.lzx.demo.base.Entity;

public class ItemModel extends Entity {
    public long id;
    public String title;
    public int imgRes;
    public String imgUrl;
    public int height ;
}