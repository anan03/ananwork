package com.lzx.demo.bean;

import com.lzx.demo.base.Entity;

/**
 * Created by lizhixian on 2016/11/19.
 */

public class Goods extends Entity{
    public String title;
    public String price;
}
