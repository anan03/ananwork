package com.lzx.demo.interfaces;

/**
 * Created by faudigue on 28/04/2015.
 */
public interface Sectionizer<T>{
    public String getSectionTitle(T object);
}
