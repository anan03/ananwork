package com.lzx.demo.bean;

import java.util.List;

/**
 * Created by lizhixian on 2016/11/19.
 */

public class Order {
    private String shopName;
    private List<Goods> goodsList;
}
