package com.lzx.demo.base;


import java.io.Serializable;

/**
 * 实体类
 * 
 */
public abstract class Entity implements Serializable{
    public int id;
    public int type; // content type

}
