package com.lzx.demo.bean;

/**
 * Created by lizhixian on 2016/12/24.
 */

public class Product{
    public String title;
    public int coverResId;

    public Product(String title, int coverResId) {
        this.title = title;
        this.coverResId = coverResId;
    }

}
