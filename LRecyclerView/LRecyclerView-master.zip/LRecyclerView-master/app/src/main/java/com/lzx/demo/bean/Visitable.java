package com.lzx.demo.bean;


import com.lzx.demo.type.TypeFactory;

public interface Visitable {

    int type(TypeFactory typeFactory);

}
