package com.lzx.demo.imageloader;

import android.content.Context;

/**
 * Created by Lzx on 2016/12/8.
 * using Picasso to load image
 */

public class PicassoImageLoaderStrategy implements BaseImageLoaderStrategy {
    @Override
    public void loadImage(Context context, ImageLoader imageLoader) {
        //Todo
    }
}
