# kstyle
KStyle是一个Android的样式开发的学习项目。

现阶段完成了shape篇、selector篇、layer-list篇、drawable汇总篇、View Animation篇、Property Animation篇

[Android样式的开发:shape篇](http://keeganlee.me/post/android/20150830)

[Android样式的开发:selector篇](http://keeganlee.me/post/android/20150905)

[Android样式的开发:selector篇](http://keeganlee.me/post/android/20150909)

[Android样式的开发:drawable汇总篇](http://keeganlee.me/post/android/20150916)

[Android样式的开发:View Animation篇](http://keeganlee.me/post/android/20151003)

[Android样式的开发:Property Animation篇](http://keeganlee.me/post/android/20151026)
